"use strict";
alert('Hello world!');
